//
// Created by sascha on 14-12-2017.
//

#ifndef SENSOR_STRUCT_MESSAGE_H
#define SENSOR_STRUCT_MESSAGE_H

int create_message(int message_flag,char *message);
int create_normal_message(char *message);
int send_schedules();

#endif //SENSOR_STRUCT_MESSAGE_H
