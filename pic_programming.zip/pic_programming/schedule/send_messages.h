//
// Created by sascha on 16-12-2017.
//

#ifndef COMMUNICATION_SEND_MESSAGES_C_H
#define COMMUNICATION_SEND_MESSAGES_C_H


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int get_digits(int score_int, char *score_char);
int send_message(char *message);

#endif //COMMUNICATION_SEND_MESSAGES_C_H
