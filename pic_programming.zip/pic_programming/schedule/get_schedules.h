//
// Created by sascha on 16-12-2017.
//

#ifndef COMMUNICATION_GET_SCHEDULES_H
#define COMMUNICATION_GET_SCHEDULES_H

#include "message.h"

#include <stdio.h>
#include "schedules.h"
#include <string.h>

int get_schedule_message(char *to_send);

#endif //COMMUNICATION_GET_SCHEDULES_H
